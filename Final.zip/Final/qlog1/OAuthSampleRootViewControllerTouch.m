/* Copyright (c) 2010 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// OAuthSampleRootViewControllerTouch.m

#import "OAuthSampleRootViewControllerTouch.h"
#import "GTMOAuthViewControllerTouch.h"
#import "SBJson.h"
static NSString *const kKeychainItemName = @"OAuth Sample: Google Contacts";
static NSString *const kShouldSaveInKeychainKey = @"shouldSaveInKeychain";


@interface OAuthSampleRootViewControllerTouch()
- (void)viewController:(GTMOAuthViewControllerTouch *)viewController
      finishedWithAuth:(GTMOAuthAuthentication *)auth
                 error:(NSError *)error;
- (void)incrementNetworkActivity:(NSNotification *)notify;
- (void)decrementNetworkActivity:(NSNotification *)notify;
- (void)signInNetworkLostOrFound:(NSNotification *)notify;
- (void)doAnAuthenticatedAPIFetch;
- (BOOL)shouldSaveInKeychain;
@end

@implementation OAuthSampleRootViewControllerTouch


@synthesize signInOutButton = mSignInOutButton;
@synthesize emailField = mEmailField;
@synthesize tokenField = mTokenField;
@synthesize indicator;


- (void)dealloc {
  NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
  [nc removeObserver:self];
  [mSignInOutButton release];
  [mEmailField release];
  [mTokenField release];
  [mAuth release];
  [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)orientation {
  // Returns non-zero on iPad, but backward compatible to SDKs earlier than 3.2.
  if (UI_USER_INTERFACE_IDIOM()) {
    return YES;
  }
  return [super shouldAutorotateToInterfaceOrientation:orientation];
}

- (BOOL)isSignedIn {
  BOOL isSignedIn = [mAuth canAuthorize];
  return isSignedIn;
}



- (IBAction)signInOutClicked:(id)sender {
  if (![self isSignedIn]) 
   {
      
       // sign in
      [self signInToGoogle];
    
   } 
  else 
   {
    
       // sign out
       [self signOut];
       
   }
  [self updateUI];
}

// UISwitch does the toggling for us. We just need to read the state.
- (IBAction)toggleShouldSaveInKeychain:(id)sender {
  [[NSUserDefaults standardUserDefaults] setBool:[sender isOn]
                                          forKey:kShouldSaveInKeychainKey];
}

- (void)signOut {
  if ([[mAuth serviceProvider] isEqual:kGTMOAuthServiceProviderGoogle]) {
    // remove the token from Google's servers
    [GTMOAuthViewControllerTouch revokeTokenForGoogleAuthentication:mAuth];
  }

  // remove the stored Google authentication from the keychain, if any
  [GTMOAuthViewControllerTouch removeParamsFromKeychainForName:kKeychainItemName];

  
  // Discard our retained authentication object.
  [self setAuthentication:nil];

  [self updateUI];
}

- (void)signInToGoogle {
  [self signOut];

  NSString *keychainItemName = nil;
  if ([self shouldSaveInKeychain]) {
    keychainItemName = kKeychainItemName;
  }

  // For GTM applications, the scope is available as
  //   NSString *scope = [[service class] authorizationScope]
  NSString *scope = @"http://www.google.com/m8/feeds/";

  // ### Important ###
  // GTMOAuthViewControllerTouch is not designed to be reused. Make a new
  // one each time you are going to show it.

  // Display the autentication view.
  GTMOAuthViewControllerTouch *viewController = [[[GTMOAuthViewControllerTouch alloc]
            initWithScope:scope
                 language:nil
           appServiceName:keychainItemName
                 delegate:self
         finishedSelector:@selector(viewController:finishedWithAuth:error:)] autorelease];

  // You can set the title of the navigationItem of the controller here, if you want.

  // Optional: display some html briefly before the sign-in page loads
  NSString *html = @"<html><body bgcolor=silver><div align=center>Loading sign-in page...</div></body></html>";
  [viewController setInitialHTMLString:html];

  [[self navigationController] pushViewController:viewController animated:YES];
}




- (void)viewController:(GTMOAuthViewControllerTouch *)viewController
      finishedWithAuth:(GTMOAuthAuthentication *)auth
                 error:(NSError *)error {
  if (error != nil) {
    // Authentication failed (perhaps the user denied access, or closed the
    // window before granting access)
    NSLog(@"Authentication error: %@", error);
    NSData *responseData = [[error userInfo] objectForKey:@"data"]; // kGTMHTTPFetcherStatusDataKey
    if ([responseData length] > 0) {
      // show the body of the server's authentication failure response
      NSString *str = [[[NSString alloc] initWithData:responseData
                                             encoding:NSUTF8StringEncoding] autorelease];
      NSLog(@"%@", str);
    }

    [self setAuthentication:nil];
  } else {
    // Authentication succeeded
    //
    // At this point, we either use the authentication object to explicitly
    // authorize requests, like
    //
    //   [auth authorizeRequest:myNSURLMutableRequest]
    //
    // or store the authentication object into a GTM service object like
    //
    //   [[self contactService] setAuthorizer:auth];

    // save the authentication object
    [self setAuthentication:auth];

    // Just to prove we're signed in, we'll attempt an authenticated fetch for the
    // signed-in user
    [self doAnAuthenticatedAPIFetch];
  }

  [self updateUI];
}

- (void)doAnAuthenticatedAPIFetch {
  NSString *urlStr;
   
    // Google Contacts feed
    urlStr = @"http://www.google.com/m8/feeds/contacts/default/thin";
  
  NSURL *url = [NSURL URLWithString:urlStr];
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
  [mAuth authorizeRequest:request];

  // Note that for a request with a body, such as a POST or PUT request, the
  // library will include the body data when signing only if the request has
  // the proper content type header:
  //
  //   [request setValue:@"application/x-www-form-urlencoded"
  //  forHTTPHeaderField:@"Content-Type"];

  // Synchronous fetches like this are a really bad idea in Cocoa applications
  //
  // For a very easy async alternative, we could use GTMHTTPFetcher
  NSError *error = nil;
  NSURLResponse *response = nil;
  NSData *data = [NSURLConnection sendSynchronousRequest:request
                                       returningResponse:&response
                                                   error:&error];
  if (data) {
    // API fetch succeeded
    NSString *str = [[[NSString alloc] initWithData:data
                                           encoding:NSUTF8StringEncoding] autorelease];
    NSLog(@"API response: %@", str);
  } else {
    // fetch failed
    NSLog(@"API fetch error: %@", error);
  }
}

#pragma mark -

- (void)incrementNetworkActivity:(NSNotification *)notify {
  ++mNetworkActivityCounter;
  if (1 == mNetworkActivityCounter) {
    UIApplication *app = [UIApplication sharedApplication];
    [app setNetworkActivityIndicatorVisible:YES];
  }
}

- (void)decrementNetworkActivity:(NSNotification *)notify {
  --mNetworkActivityCounter;
  if (0 == mNetworkActivityCounter) {
    UIApplication *app = [UIApplication sharedApplication];
    [app setNetworkActivityIndicatorVisible:NO];
  }
}

- (void)signInNetworkLostOrFound:(NSNotification *)notify {
  if ([[notify name] isEqual:kGTMOAuthNetworkLost]) {
    // network connection was lost; alert the user, or dismiss
    // the sign-in view with
    //   [[[notify object] delegate] cancelSigningIn];
  } else {
    // network connection was found again
  }
}

#pragma mark -

- (void)updateUI {
  // update the text showing the signed-in state and the button title
   // mSignInOutButton.hidden=TRUE;
    indicator.hidden=FALSE;
    [indicator startAnimating];
  // A real program would use NSLocalizedString() for strings shown to the user.
  if ([self isSignedIn])
   {
    
        
        
      // signed in
      NSString *email = [mAuth userEmail];
    

      NSUserDefaults * userDeafaults=[NSUserDefaults standardUserDefaults];
      [userDeafaults setValue:email forKey:@"user"];
      
      
      
      NSUserDefaults * device=[NSUserDefaults standardUserDefaults];
      NSString * assetidRetrieved = [device valueForKey:@"assetid"];
  
      
       if([assetidRetrieved length]==0)
        {
          
          
          
          UIViewController *newViewController =
          [self.storyboard instantiateViewControllerWithIdentifier:@"SetDeviceid"];
          [self presentModalViewController:newViewController animated:NO];
          
          
        }
      
       else  
        { 
          
          
                    
          NSString *post =[[NSString alloc] initWithFormat:@"deviceid=%@&username=%@",assetidRetrieved,email];
          
          NSURL *url = [NSURL URLWithString:@"http://10.3.0.151:8888/qlog/devicestatus.php"]; // Modify this to match your url.
          
          
          NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
          
          NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
          
          
            
            
          NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
          [request setURL:url];
          
          [request setHTTPMethod:@"POST"];
          
          [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
          
          [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
          
          [request setHTTPBody:postData]; 
          
          NSError *error;
          
          NSURLResponse *response;
          
          NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
          
          NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
          
          //getting response...   
          
          SBJsonParser * JsonParser=[SBJsonParser new];
          
          NSDictionary *DetailsOfCurrentdevice = [JsonParser objectWithString:responseData error:nil];
          
          
          NSString *Status=[DetailsOfCurrentdevice valueForKey:@"Status"];
          
          
          /*   
           
           NSString *deviceid=[DetailsOfCurrentdevice valueForKey:@"deviceid"];
           NSString *devicename=[DetailsOfCurrentdevice valueForKey:@"devicename"];
           NSString *manufacturer=[DetailsOfCurrentdevice valueForKey:@"mnfctr"];
           NSString *location=[DetailsOfCurrentdevice valueForKey:@"loc"];
           NSString *os=[DetailsOfCurrentdevice valueForKey:@"os"];
           */ 
          
          
          /* NSString *resultcategory=[detailsOfCurrentAsset valueForKey:@"category"];
           NSString *resultmodel=[detailsOfCurrentAsset valueForKey:@"model"];*/
          //checking for successful login...
          //[dict objectForKey:@"email"];
          
          
          
           if ([Status isEqualToString:@"Unavailable"])
              
            {    
                    
          
              
              UIViewController *newViewController =
              [self.storyboard instantiateViewControllerWithIdentifier:@"devicestatus"];
              
              [self presentModalViewController:newViewController animated:NO];
              
              
              
              
          
            }
          
    
          
           else
            {
          
          
          
          
            NSString *post =[[NSString alloc] initWithFormat:@"username=%@",email];
          
            NSURL *url=[NSURL URLWithString:@"http://10.3.0.151:8888/qlog/rolecheck.php"];
          
          
            //NSData *urlData=[self webService:post :url];
          
            NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
          
            NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
          
            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
          
            [request setURL:url];
          
            [request setHTTPMethod:@"POST"];
          
            [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
          
            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
          
            [request setHTTPBody:postData];   
          
            NSError *error;
          
            NSURLResponse *response;
          
          
            NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
          
          
          
            NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
          
            //getting response...    
          
            SBJsonParser * jsonParser=[SBJsonParser new];
          
            NSArray *detailsOfCurrentUser = [jsonParser objectWithString:responseData error:nil];
          
            NSString * role=[detailsOfCurrentUser objectAtIndex:0];
          
          
          
            if ([role isEqualToString:@"admin"])
             {
              
              UITabBarController *tabBarController; 
              tabBarController= (UITabBarController *)[self.storyboard instantiateViewControllerWithIdentifier:@"welcome"];
              
              [self presentModalViewController:tabBarController animated:YES];
            }
           else
             
            {
         
             UITabBarController *tabBarController; 
             tabBarController= (UITabBarController *)[self.storyboard instantiateViewControllerWithIdentifier:@"welcome1"];
             
             [self presentModalViewController:tabBarController animated:YES];
         
         
         
            }
          
       }
     
    }
      

  } 
else 
  {
    // signed out
    
    [mSignInOutButton setTitle:@"Sign In using QBurst account"forState:normal];
  }
  
}

- (void)setAuthentication:(GTMOAuthAuthentication *)auth {
  [mAuth autorelease];
  mAuth = [auth retain];
}

- (BOOL)shouldSaveInKeychain {
  return [[NSUserDefaults standardUserDefaults] boolForKey:kShouldSaveInKeychainKey];
}

- (void)viewDidUnload {
    [self setIndicator:nil];
    [self setIndicator:nil];
    [super viewDidUnload];
}
@end

