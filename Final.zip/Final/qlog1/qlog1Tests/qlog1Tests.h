//
//  qlog1Tests.h
//  qlog1Tests
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface qlog1Tests : SenTestCase

@end
