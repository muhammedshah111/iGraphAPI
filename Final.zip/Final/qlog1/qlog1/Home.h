//
//  Home.h
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//
@class GTMOAuthAuthentication;

#import <UIKit/UIKit.h>
@interface Home : UIViewController
{


    IBOutlet UIButton *CheckOut;

    IBOutlet UIButton *CheckIn;
        
    IBOutlet UIBarButtonItem *signout;
   GTMOAuthAuthentication *mAuth; 
    
}
- (IBAction)CheckOut:(id)sender;
- (IBAction)CheckIn:(id)sender;

- (IBAction)signout:(id)sender;







@end
