//
//  DeviceDetails.m
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "DeviceDetails.h"
#import "SBJson.h"

@implementation DeviceDetails
@synthesize DeviceName;
@synthesize DeviceId;
@synthesize Manufacturer;
@synthesize Os;
@synthesize Location;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    
    
    
    
    
    
    
    
    
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    
    NSUserDefaults * device=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetidRetrieved = [device valueForKey:@"assetid"];
    NSLog(@"%@",assetidRetrieved);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    NSString *post =[[NSString alloc] initWithFormat:@"username=%@",assetidRetrieved];
    
    
    
    
    
    NSURL *url = [NSURL URLWithString:@"http://10.3.0.151:8888/qlog/stup.php"]; // Modify this to match your url.
    
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    
    
    
    
    
    
    
    
    
    
    
 	
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    
    
    
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData]; 
    
    NSError *error;
    
    NSURLResponse *response;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...   
    
    SBJsonParser * JsonParser=[SBJsonParser new];
    
    NSDictionary *DetailsOfCurrentdevice = [JsonParser objectWithString:responseData error:nil];
    
    NSString *deviceid=[DetailsOfCurrentdevice valueForKey:@"deviceid"];
    NSString *devicename=[DetailsOfCurrentdevice valueForKey:@"devicename"];
    NSString *manufacturer=[DetailsOfCurrentdevice valueForKey:@"mnfctr"];
    NSString *location=[DetailsOfCurrentdevice valueForKey:@"loc"];
    NSString *os=[DetailsOfCurrentdevice valueForKey:@"os"];
    
    
    
    /* NSString *resultcategory=[detailsOfCurrentAsset valueForKey:@"category"];
     NSString *resultmodel=[detailsOfCurrentAsset valueForKey:@"model"];*/
    //checking for successful login...
    //[dict objectForKey:@"email"];
    
    NSLog(@"%@",deviceid);
    DeviceId.text=deviceid;
    
    NSLog(@"%@",devicename);
    DeviceName.text=devicename;
    
    NSLog(@"%@",location);
    Location.text=location;
    
    NSLog(@"%@",manufacturer);
    Manufacturer.text=manufacturer;
    
    NSLog(@"%@",os);
    Os.text=os;
    
    
    
    
    
    
    
}



- (void)viewDidUnload
{
    DeviceName = nil;
    DeviceId = nil;
    Manufacturer = nil;
    Os = nil;
    Location = nil;
    [self setDeviceName:nil];
    [self setDeviceId:nil];
    [self setManufacturer:nil];
    [self setOs:nil];
    [self setLocation:nil];
        signout = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)signout:(id)sender {
    /*  OAuthSampleRootViewControllerTouch *log;
     log=[[OAuthSampleRootViewControllerTouch alloc]init];
     [log signOut];
     
     
     UIViewController *newViewController =
     [self.storyboard instantiateViewControllerWithIdentifier:@"oath"];
     
     [self presentModalViewController:newViewController animated:NO];*/
    UINavigationController *navController;
    navController= (UINavigationController *)[self.storyboard instantiateViewControllerWithIdentifier:@"oath1"];
    
    [self presentModalViewController:navController animated:YES];
    
    
    
    
    // [log updateUI];
 
    
    
    
}
@end
