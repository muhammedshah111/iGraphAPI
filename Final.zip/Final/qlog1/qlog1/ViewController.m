//
//  ViewController.m
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "SBJson.h"
@implementation ViewController
@synthesize UserName;
@synthesize Password;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    UserName = nil;
    Password = nil;
    [self setUserName:nil];
    [self setPassword:nil];
    SignIn = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)SignIn:(id)sender {
    
    NSString *post =[[NSString alloc] initWithFormat:@"username=%@&password=%@",UserName.text,Password.text];
    
    NSURL *url=[NSURL URLWithString:@"http://localhost:8888/login.php"];
    
    
    //NSData *urlData=[self webService:post :url];
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];   
    
    NSError *error;
    
    NSURLResponse *response;
    
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...    
    
    SBJsonParser * jsonParser=[SBJsonParser new];
    
    NSArray *detailsOfCurrentUser = [jsonParser objectWithString:responseData error:nil];
    
    NSString * resultOfLoginAction=[detailsOfCurrentUser objectAtIndex:0];
    /*NSString * Devicename=[detailsOfCurrentUser objectAtIndex:1];*/
    //checking for successful login...
    
    //NSLog(@"%@",resultOfLoginAction);
    
    if([resultOfLoginAction isEqualToString:@"success"])
        
    {     
                
        
        UIViewController *newViewController =
        [self.storyboard instantiateViewControllerWithIdentifier:@"Home"];
        
        //[self presentModalViewController:newViewController animated:NO];
        [self.view addSubview:newViewController.view];

        
        
        
        
        
        
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" 
                                                        message:resultOfLoginAction
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles: nil];
		alert.tag=1;
        [alert show];
        
        
    }
    
}
-(void) touchesBegan :(NSSet *) touches withEvent:(UIEvent *)event

{
    
    [UserName resignFirstResponder];
    
    [Password resignFirstResponder];
    
    [super touchesBegan:touches withEvent:event ];
    
}


    
    
    

@end
