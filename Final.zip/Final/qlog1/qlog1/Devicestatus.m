//
//  Devicestatus.m
//  qlog1
//
//  Created by qbadmin on 11/15/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Devicestatus.h"
#import "SBJson.h"
@implementation Devicestatus
@synthesize status;
@synthesize username;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    
    NSUserDefaults * device=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetidRetrieved = [device valueForKey:@"assetid"];
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    NSString *post =[[NSString alloc] initWithFormat:@"deviceid=%@",assetidRetrieved];
    
    
    
    
    
    NSURL *url = [NSURL URLWithString:@"http://10.3.0.151:8888/qlog/status.php"]; // Modify this to match your url.
    
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    
    
    
    
    
    
    
    
    
    
    
 	
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    
    
    
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData]; 
    
    NSError *error;
    
    NSURLResponse *response;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...   
    
    SBJsonParser * JsonParser=[SBJsonParser new];
    
    NSDictionary *DetailsOfCurrentdevice = [JsonParser objectWithString:responseData error:nil];
    
    
    
    NSString *Username=[DetailsOfCurrentdevice valueForKey:@"Username"];
    
 /*   
    
    NSString *deviceid=[DetailsOfCurrentdevice valueForKey:@"deviceid"];
    NSString *devicename=[DetailsOfCurrentdevice valueForKey:@"devicename"];
    NSString *manufacturer=[DetailsOfCurrentdevice valueForKey:@"mnfctr"];
    NSString *location=[DetailsOfCurrentdevice valueForKey:@"loc"];
    NSString *os=[DetailsOfCurrentdevice valueForKey:@"os"];
   */ 
    
    
    /* NSString *resultcategory=[detailsOfCurrentAsset valueForKey:@"category"];
     NSString *resultmodel=[detailsOfCurrentAsset valueForKey:@"model"];*/
    //checking for successful login...
    //[dict objectForKey:@"email"];
  
    
    
        username.hidden=FALSE;
        NSLog(@"%@",Username);
        username.text=Username;
    
    
    
    
    
    
    
    
    
  /*  
    
    
    NSLog(@"%@",deviceid);
    DeviceId.text=deviceid;
    
    NSLog(@"%@",devicename);
    DeviceName.text=devicename;
    
    NSLog(@"%@",location);
    Location.text=location;
    
    NSLog(@"%@",manufacturer);
    Manufacturer.text=manufacturer;
    
    NSLog(@"%@",os);
    Os.text=os;
    
    
    */
    
    
    
    
}

- (void)viewDidUnload
{
    status = nil;
    username = nil;
    [self setStatus:nil];
    [self setUsername:nil];
    handled = nil;
    signout = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)signout:(id)sender {
    
    /*  OAuthSampleRootViewControllerTouch *log;
     log=[[OAuthSampleRootViewControllerTouch alloc]init];
     [log signOut];
     
     
     UIViewController *newViewController =
     [self.storyboard instantiateViewControllerWithIdentifier:@"oath"];
     
     [self presentModalViewController:newViewController animated:NO];*/
    UINavigationController *navController;
    navController= (UINavigationController *)[self.storyboard instantiateViewControllerWithIdentifier:@"oath1"];
    
    [self presentModalViewController:navController animated:YES];
    
    
    
    
    // [log updateUI];
    
   
    
    
}
@end
