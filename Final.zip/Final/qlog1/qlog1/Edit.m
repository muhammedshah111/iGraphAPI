//
//  Edit.m
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Edit.h"
#import "SBJson.h"
@implementation Edit
@synthesize MnfctrEdit;
@synthesize OsEdit;
@synthesize LocEdit;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    
    MnfctrEdit = nil;
    MnfctrEdit = nil;
    OsEdit = nil;
    LocEdit = nil;
    [self setMnfctrEdit:nil];
    [self setOsEdit:nil];
    [self setLocEdit:nil];
    idReset = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)UpdateAction:(id)sender {
    
    
    NSUserDefaults * device=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetidRetrieved = [device valueForKey:@"assetid"];

    
    NSString *post =[[NSString alloc] initWithFormat:@"deviceid=%@&manufacturer=%@&os=%@&location=%@",assetidRetrieved,MnfctrEdit.text,OsEdit.text,LocEdit.text];
    
    
    
    NSURL *url=[NSURL URLWithString:@"http://10.3.0.151:8888/update.php"];
    
    
    //NSData *urlData=[self webService:post :url];
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];   
    
    NSError *error;
    
    NSURLResponse *response;
    
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...    
    
    SBJsonParser * jsonParser=[SBJsonParser new];
    
    NSArray *detailsOfCurrentUser = [jsonParser objectWithString:responseData error:nil];
    
    NSString * resultOfLoginAction=[detailsOfCurrentUser objectAtIndex:0];
    /*NSString * Devicename=[detailsOfCurrentUser objectAtIndex:1];*/
    //checking for successful login...
    
    //NSLog(@"%@",resultOfLoginAction);
    
    if([resultOfLoginAction isEqualToString:@"success"])
        
    {     
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" 
                        message:@"Successfully updated"
                        delegate:self 
                        cancelButtonTitle:@"OK" 
                        otherButtonTitles: nil];
        alert.tag=0;
		[alert show];
        /* UIViewController *newViewController =
         [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
         //[self presentModalViewController:newViewController animated:NO];
         [self.view addSubview:newViewController.view];*/
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" 
                    message:@"Invalid entry"
                    delegate:self 
                    cancelButtonTitle:@"OK" 
                    otherButtonTitles: nil];
		alert.tag=1;
        [alert show];
        
        
    }
}

- (IBAction)idReset:(id)sender {
    
    
     [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"assetid"];
    }
-(void) touchesBegan :(NSSet *) touches withEvent:(UIEvent *)event

{
    
    [MnfctrEdit resignFirstResponder];
    
    [OsEdit resignFirstResponder];
    
    [LocEdit resignFirstResponder];
    
    [super touchesBegan:touches withEvent:event ];
    
}  

  
    

@end
