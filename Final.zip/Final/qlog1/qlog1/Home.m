//
//  Home.m
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Home.h"
#import "SBJson.h"
#import "OAuthSampleRootViewControllerTouch.h"
#import "GTMOAuthViewControllerTouch.h"
@implementation Home




- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSUserDefaults * device=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetid = [device valueForKey:@"assetid"];

    NSString *post =[[NSString alloc] initWithFormat:@"deviceid=%@",assetid];
    
    
    
    
    
    NSURL *url=[NSURL URLWithString:@"http://10.3.0.151:8888/qlog/statuscheck.php"];
    
    
    //NSData *urlData=[self webService:post :url];
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];   
    
    NSError *error;
    
    NSURLResponse *response;
    
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...    
    
    SBJsonParser * jsonParser=[SBJsonParser new];
    
    NSArray *detailsOfCurrentstatus = [jsonParser objectWithString:responseData error:nil];
    
    NSString * resultOfstatusAction=[detailsOfCurrentstatus objectAtIndex:0];
    
    if([resultOfstatusAction isEqualToString:@"success"])
        
    {     
        
        CheckOut.hidden = TRUE;
        CheckIn.hidden = FALSE;
        
        
        
    }
    else
    {
        CheckOut.hidden = FALSE;
        CheckIn.hidden = TRUE; 
        
    }
    
    
    
    
    
    
    
    
    
    
}

- (void)viewDidUnload
{
    CheckOut = nil;
    CheckIn = nil;
    
    
    signout = nil;
    
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)CheckOut:(id)sender {
    NSUserDefaults * devic=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetidRetrieved = [devic valueForKey:@"assetid"];

    
    NSUserDefaults * device=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * useridRetrieved = [device valueForKey:@"user"];

    
    
    
    NSString *post =[[NSString alloc] initWithFormat:@"deviceid=%@&username=%@",assetidRetrieved,useridRetrieved];
    
    
    
    
    
    NSURL *url=[NSURL URLWithString:@"http://10.3.0.151:8888/qlog/checkout.php"];
    
    
    //NSData *urlData=[self webService:post :url];
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];   
    
    NSError *error;
    
    NSURLResponse *response;
    
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...    
    
    SBJsonParser * jsonParser=[SBJsonParser new];
    
    NSArray *detailsOfCurrentUser = [jsonParser objectWithString:responseData error:nil];
    
    NSString * resultOfLoginAction=[detailsOfCurrentUser objectAtIndex:0];
    
    if([resultOfLoginAction isEqualToString:@"success"])
        
    {     
        
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" 
                                                        message:@"device successfully checked out"
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles: nil];
        alert.tag=0;
        [alert show];
        
        CheckOut.hidden = TRUE;
        CheckIn.hidden  = FALSE;        
        
    }
    
    
 
    
    
    
    
    
    
    
}

- (IBAction)CheckIn:(id)sender {
    
    NSUserDefaults * dev=[NSUserDefaults standardUserDefaults];
    //text1.text=[user valueForKey:@"username"];
    NSString * assetidRetrieved = [dev valueForKey:@"assetid"];

    NSString *post =[[NSString alloc] initWithFormat:@"deviceid=%@",assetidRetrieved];
    
    
    
    
    
    NSURL *url=[NSURL URLWithString:@"http://10.3.0.151:8888/qlog/checkin.php"];
    
    
    //NSData *urlData=[self webService:post :url];
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData];   
    
    NSError *error;
    
    NSURLResponse *response;
    
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...    
    
    SBJsonParser * jsonParser=[SBJsonParser new];
    
    NSArray *detailsOfCurrentUser = [jsonParser objectWithString:responseData error:nil];
    
    NSString * resultOfcheckinAction=[detailsOfCurrentUser objectAtIndex:0];
    
    if([resultOfcheckinAction isEqualToString:@"success"])
        
    {     
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" 
                                                        message:@"device successfully checked in"
                                                       delegate:self 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles: nil];
        alert.tag=1;
        [alert show];
        
        CheckIn.hidden  = TRUE;
        CheckOut.hidden = FALSE;
        
        
    }
    
    
    
 
    
    
    
    
    
    
}

- (IBAction)signout:(id)sender {
    /*  OAuthSampleRootViewControllerTouch *log;
     log=[[OAuthSampleRootViewControllerTouch alloc]init];
     [log signOut];
     
     
     UIViewController *newViewController =
     [self.storyboard instantiateViewControllerWithIdentifier:@"oath"];
     
     [self presentModalViewController:newViewController animated:NO];*/
    UINavigationController *navController;
    navController= (UINavigationController *)[self.storyboard instantiateViewControllerWithIdentifier:@"oath1"];
    
    [self presentModalViewController:navController animated:YES];
    
    
    
    
    // [log updateUI];
    

    
    
    
    
    
}


@end
