//
//  Edit.h
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Edit : UIViewController
{


    IBOutlet UITextField *MnfctrEdit;
    
    IBOutlet UITextField *OsEdit;
    
    IBOutlet UITextField *LocEdit;
    
    IBOutlet UIButton *UpdateAction;
    
    
    IBOutlet UIButton *idReset;
}
@property (strong, nonatomic) IBOutlet UITextField *MnfctrEdit;
@property (strong, nonatomic) IBOutlet UITextField *OsEdit;

@property (strong, nonatomic) IBOutlet UITextField *LocEdit;



- (IBAction)UpdateAction:(id)sender;

- (IBAction)idReset:(id)sender;


@end
