//
//  Devicestatus.h
//  qlog1
//
//  Created by qbadmin on 11/15/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Devicestatus : UIViewController
{

    IBOutlet UIBarButtonItem *signout;

    IBOutlet UILabel *status;


    IBOutlet UILabel *username;


    IBOutlet UILabel *handled;

}


@property (strong, nonatomic) IBOutlet UILabel *status;


@property (strong, nonatomic) IBOutlet UILabel *username;

- (IBAction)signout:(id)sender;



@end
