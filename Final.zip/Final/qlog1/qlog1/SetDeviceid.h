//
//  SetDeviceid.h
//  qlog1
//
//  Created by qbadmin on 11/14/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetDeviceid : UIViewController
{


    IBOutlet UITextField *DeviceId;



    IBOutlet UIButton *SetDeviceId;


}

@property (strong, nonatomic) IBOutlet UITextField *DeviceId;

- (IBAction)SetDeviceId:(id)sender;




@end
