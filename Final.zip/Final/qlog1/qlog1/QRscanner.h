//
//  QRscanner.h
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"

@interface QRscanner : UIViewController<ZBarReaderDelegate>
{


    IBOutlet UIButton *StartQR;

    

    IBOutlet UITextView *resultText;
    IBOutlet UIImageView *resultImage;
   
    IBOutlet UIBarButtonItem *signout;

    IBOutlet UILabel *name;

}

@property (strong, nonatomic) IBOutlet UITextView *resultText;
@property (strong, nonatomic) IBOutlet UIImageView *resultImage;

@property (strong, nonatomic) IBOutlet UILabel *name;


- (IBAction)StartQR:(id)sender;

- (IBAction)signout:(id)sender;


@end
