//
//  DeviceDetails.h
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceDetails : UIViewController
{


    IBOutlet UILabel *DeviceName;

    IBOutlet UILabel *DeviceId;

    IBOutlet UILabel *Manufacturer;


    IBOutlet UILabel *Os;


    IBOutlet UILabel *Location;
    

    IBOutlet UIBarButtonItem *signout;


}


@property (strong, nonatomic) IBOutlet UILabel *DeviceName;

@property (strong, nonatomic) IBOutlet UILabel *DeviceId;

@property (strong, nonatomic) IBOutlet UILabel *Manufacturer;

@property (strong, nonatomic) IBOutlet UILabel *Os;

@property (strong, nonatomic) IBOutlet UILabel *Location;

- (IBAction)signout:(id)sender;








@end
