//
//  SetDeviceid.m
//  qlog1
//
//  Created by qbadmin on 11/14/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "SetDeviceid.h"
#import "SBJson.h"
@implementation SetDeviceid
@synthesize DeviceId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    DeviceId = nil;
    SetDeviceId = nil;
    [self setDeviceId:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)SetDeviceId:(id)sender {
    
    
    
    if([DeviceId.text length]==0)
        
    {
        
        
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" 
                              
                                                        message:@"enter asset id"
                              
                                                       delegate:self
                              
                                              cancelButtonTitle:@"OK" 
                              
                                              otherButtonTitles: nil];
        
        alert.tag =3;
        
        [alert show];
        
        
        
        
        
        
        
        
        
    }
    
    else
        
    {
        
        NSUserDefaults * userDeafaults=[NSUserDefaults standardUserDefaults];
        
        [userDeafaults setValue:DeviceId.text forKey:@"assetid"];
        
        
        
        
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Info" 
                              
                                    message:@"ASSET id saved"
                              
                                                       delegate:nil
                              
                                              cancelButtonTitle:@"OK" 
                              
                                              otherButtonTitles: nil];
        
        
        
        [alert show];
        
        NSUserDefaults * device=[NSUserDefaults standardUserDefaults];
        //text1.text=[user valueForKey:@"username"];
        NSString * useridRetrieved = [device valueForKey:@"user"];
        
        
        NSString *post =[[NSString alloc] initWithFormat:@"username=%@",useridRetrieved];
        
        NSURL *url=[NSURL URLWithString:@"http://10.3.0.151:8888/qlog/rolecheck.php"];
        
        
        //NSData *urlData=[self webService:post :url];
        
        NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
        
        NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        
        [request setURL:url];
        
        [request setHTTPMethod:@"POST"];
        
        [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
        
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        
        [request setHTTPBody:postData];   
        
        NSError *error;
        
        NSURLResponse *response;
        
        
        NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
        
        
        
        NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
        
        //getting response...    
        
        SBJsonParser * jsonParser=[SBJsonParser new];
        
        NSArray *detailsOfCurrentUser = [jsonParser objectWithString:responseData error:nil];
        
        NSString * role=[detailsOfCurrentUser objectAtIndex:0];
        
        
        
        if ([role isEqualToString:@"admin"])
        {
            
            UITabBarController *tabBarController; 
            tabBarController= (UITabBarController *)[self.storyboard instantiateViewControllerWithIdentifier:@"welcome"];
            
            [self presentModalViewController:tabBarController animated:YES];
        }
        else
            
        {
            
            UITabBarController *tabBarController; 
            tabBarController= (UITabBarController *)[self.storyboard instantiateViewControllerWithIdentifier:@"welcome1"];
            
            [self presentModalViewController:tabBarController animated:YES];
            
            
            
        }
        
        
  

    }

}   
    
-(void) touchesBegan :(NSSet *) touches withEvent:(UIEvent *)event

{
    
    [DeviceId resignFirstResponder];
    
   
    [super touchesBegan:touches withEvent:event ];
    
}   
    
    
    
    
    
    
    
    
    
    
    
    
    

@end
