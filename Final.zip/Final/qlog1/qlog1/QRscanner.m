//
//  QRscanner.m
//  qlog1
//
//  Created by qbadmin on 11/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "QRscanner.h"
#import "SBJson.h"

@implementation QRscanner
@synthesize resultText;

@synthesize resultImage;
@synthesize name;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    StartQR = nil;
    
    signout = nil;
    resultText = nil;
    [self setResultText:nil];
    resultImage = nil;
    [self setResultImage:nil];
    resultText = nil;
    [self setResultText:nil];
    name = nil;
    [self setName:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)StartQR:(id)sender {
    
    // ADD: present a barcode reader that scans from the camera feed
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    reader.readerDelegate = self;
    reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    
    ZBarImageScanner *scanner = reader.scanner;
    // TODO: (optional) additional reader configuration here
    
    // EXAMPLE: disable rarely used I2/5 to improve performance
    [scanner setSymbology: ZBAR_I25
                   config: ZBAR_CFG_ENABLE
                       to: 0];
    
    // present and release the controller
    [self presentModalViewController: reader
                            animated: YES];
  //  [reader release];   
    
}

- (IBAction)signout:(id)sender {
    
    /*  OAuthSampleRootViewControllerTouch *log;
     log=[[OAuthSampleRootViewControllerTouch alloc]init];
     [log signOut];
     
     
     UIViewController *newViewController =
     [self.storyboard instantiateViewControllerWithIdentifier:@"oath"];
     
     [self presentModalViewController:newViewController animated:NO];*/
    UINavigationController *navController;
    navController= (UINavigationController *)[self.storyboard instantiateViewControllerWithIdentifier:@"oath1"];
    
    [self presentModalViewController:navController animated:YES];
    
    
    
    
    // [log updateUI];
    
   
    
}
- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    // ADD: get the decode results
    id<NSFastEnumeration> results =
    [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        // EXAMPLE: just grab the first barcode
        break;
    
    // EXAMPLE: do something useful with the barcode data
    resultText.text = symbol.data;
    
    // EXAMPLE: do something useful with the barcode image
    resultImage.image =
    [info objectForKey: UIImagePickerControllerOriginalImage];
    
    // ADD: dismiss the controller (NB dismiss from the *reader*!)
    [reader dismissModalViewControllerAnimated: YES];
    
    NSString *post =[[NSString alloc] initWithFormat:@"username=%@",symbol.data];
    
    
    
    
    
    NSURL *url = [NSURL URLWithString:@"http://10.3.0.151:8888/qlog/stup.php"]; // Modify this to match your url.
    
    
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", [postData length]];
    
    
    
    
    
    
    
    
    
    
    
    
 	
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    
    [request setHTTPMethod:@"POST"];
    
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    
    
    
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    [request setHTTPBody:postData]; 
    
    NSError *error;
    
    NSURLResponse *response;
    
    NSData *urlData=[NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
    
    NSString *responseData=[[NSString alloc]initWithData:urlData encoding:NSUTF8StringEncoding];
    
    //getting response...   
    
    SBJsonParser * JsonParser=[SBJsonParser new];
    
    NSDictionary *DetailsOfCurrentdevice = [JsonParser objectWithString:responseData error:nil];
    
    
    NSString *devicename=[DetailsOfCurrentdevice valueForKey:@"devicename"];
        
    
    /* NSString *resultcategory=[detailsOfCurrentAsset valueForKey:@"category"];
     NSString *resultmodel=[detailsOfCurrentAsset valueForKey:@"model"];*/
    //checking for successful login...
    //[dict objectForKey:@"email"];
    
     
    NSLog(@"%@",devicename);
    name.text=devicename;
    
  
    
    
}


@end
